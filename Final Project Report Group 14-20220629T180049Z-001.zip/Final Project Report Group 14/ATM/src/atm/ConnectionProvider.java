package atm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionProvider {

    Connection con;
    Statement stm;
    ResultSet rs;
    ResultSet rs1;

    public ConnectionProvider() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/atmaccount", "root", "Javalover123");
            stm = con.createStatement();
        } catch (Exception ex) {
            System.out.println(ex);

        }
    }

    private static class statement {

        public statement() {
        }
    }

}
