/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package atm;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.netbeans.lib.awtextra.AbsoluteLayout;

/**
 *
 * @author Ayaz Hussain
 */
public class WithDrawPage extends javax.swing.JFrame {

    /**
     * Creates new form WithDrawPage
     */
    ConnectionProvider jdbc;

    static String password, amount, userId;
//   // static String password, amount1;
//   static String s1, amount2, userId, fname, lname;
//    static int Requiredamount1 = 0, totalamount = 0, remianingAmount = 0;

    public WithDrawPage(String password1) {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        jdbc = new ConnectionProvider();
        this.password = password1;
        //System.out.print(password);
        String s1 = "select* from accountinfo where password =" + password + "";
        try {
            jdbc.rs = jdbc.stm.executeQuery(s1);
            jdbc.rs.next();
            amount = jdbc.rs.getString(6);
            userId = jdbc.rs.getString(1);

        } catch (Exception e) {
            System.out.println(e);
        }
        // System.out.println(amount);
        //JFrame f=new JFrame();
        Amount.setText(amount);
        // JOptionPane.showMessageDialog(f, amount);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Amount = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        BackButton = new javax.swing.JButton();
        Thousandbuton = new javax.swing.JButton();
        twothosdButton = new javax.swing.JButton();
        fourThsndButton = new javax.swing.JButton();
        otherAmountButton = new javax.swing.JButton();
        threeThsndButton = new javax.swing.JButton();
        fiveThsndButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atm/Background.jpg"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Amount.setBackground(new java.awt.Color(255, 255, 255));
        Amount.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jPanel1.add(Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 110, 210, 50));

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 5, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel3.setText("Select your Amount");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 280, 50));

        BackButton.setBackground(new java.awt.Color(51, 51, 51));
        BackButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        BackButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atm/Back.png"))); // NOI18N
        BackButton.setText("Back");
        BackButton.setBorder(null);
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        jPanel5.add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, 120, 50));

        Thousandbuton.setBackground(new java.awt.Color(153, 255, 255));
        Thousandbuton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        Thousandbuton.setText("1000");
        Thousandbuton.setBorder(null);
        Thousandbuton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThousandbutonActionPerformed(evt);
            }
        });
        jPanel5.add(Thousandbuton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 140, 50));

        twothosdButton.setBackground(new java.awt.Color(153, 255, 255));
        twothosdButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        twothosdButton.setText("2000");
        twothosdButton.setBorder(null);
        twothosdButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twothosdButtonActionPerformed(evt);
            }
        });
        jPanel5.add(twothosdButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 140, 50));

        fourThsndButton.setBackground(new java.awt.Color(153, 255, 255));
        fourThsndButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        fourThsndButton.setText("4000");
        fourThsndButton.setBorder(null);
        fourThsndButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fourThsndButtonActionPerformed(evt);
            }
        });
        jPanel5.add(fourThsndButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, 140, 50));

        otherAmountButton.setBackground(new java.awt.Color(153, 255, 255));
        otherAmountButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        otherAmountButton.setText("Other");
        otherAmountButton.setBorder(null);
        otherAmountButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                otherAmountButtonActionPerformed(evt);
            }
        });
        jPanel5.add(otherAmountButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 320, 140, 50));

        threeThsndButton.setBackground(new java.awt.Color(153, 255, 255));
        threeThsndButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        threeThsndButton.setText("3000");
        threeThsndButton.setBorder(null);
        threeThsndButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                threeThsndButtonActionPerformed(evt);
            }
        });
        jPanel5.add(threeThsndButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 140, 50));

        fiveThsndButton.setBackground(new java.awt.Color(153, 255, 255));
        fiveThsndButton.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        fiveThsndButton.setText("5000");
        fiveThsndButton.setBorder(null);
        fiveThsndButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fiveThsndButtonActionPerformed(evt);
            }
        });
        jPanel5.add(fiveThsndButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 210, 140, 50));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 550, 500));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atm/close.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1550, 0, 40, 40));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel5.setText("Total Amount ");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 150, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/atm/Background.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1590, 900));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1590, 900));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void twothosdButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twothosdButtonActionPerformed
        // TODO add your handling code here:
        int amount1 = 0, res = 0;
        String amount2 = "";
        amount1 = 2000;
        int b = Integer.parseInt(amount);
        if (b > 0) {
            if (amount1 < b) {

                res = b - amount1;
                System.out.print(res);
                amount2 = String.valueOf(res);
                String updateQuery = "update accountinfo set amount=" + res + " where password =" + password;
                try {
                    jdbc.stm.executeUpdate(updateQuery);
                  //  System.out.print(updateQuery);
                } catch (Exception e) {
                    System.out.print(e);
                }
                int response = JOptionPane.showConfirmDialog(null, "Do you want to reciept ?", "Conform", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new WithDrawalRecieptPage(password, userId, amount1, res).setVisible(true);
                } else {
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2);
                    new TransictionPage(password).setVisible(true);
                }
            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "You don't have Sufficient Balance");
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Insufficient Balance ");
        }

        /* else
        {
           JFrame f = new JFrame();
           JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2); 
        }*/
    }//GEN-LAST:event_twothosdButtonActionPerformed

    private void ThousandbutonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThousandbutonActionPerformed
        // TODO add your handling code here:  
        int res = 0;
        String amount2 = "";
        int amount1 = 1000;
        int b = Integer.parseInt(amount);
        if (b > 0) {
            if (amount1 < b) {
                res = b - amount1;
                amount2 = String.valueOf(res);
                String updateAmount = "update accountinfo set amount=" + amount2 + " where password =" + password;
                try {
                    jdbc.stm.executeUpdate(updateAmount);
                    System.out.print(updateAmount);
                } catch (Exception e) {
                    System.out.print(e);
                }
                int response = JOptionPane.showConfirmDialog(null, "Do you want to reciept ?", "Conform", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new WithDrawalRecieptPage(password, userId, amount1, res).setVisible(true);
                } else {
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2);
                    new TransictionPage(password).setVisible(true);
                }

            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "You dont have Enough balance:");
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Insufficient Balance ");
        }

    }//GEN-LAST:event_ThousandbutonActionPerformed

    private void threeThsndButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_threeThsndButtonActionPerformed
        // TODO add your handling code here:
        int res = 0;
        int amount1 = 3000;
        int b = Integer.parseInt(amount);
        if (b > 0) {
            if (amount1 < b) {

                res = b - amount1;
                String amount2 = String.valueOf(res);
                String updateQuery = "update accountinfo set amount=" + amount2 + " where password =" + password;
                try {
                    jdbc.stm.executeUpdate(updateQuery);
                    System.out.print(updateQuery);
                } catch (Exception e) {
                    System.out.print(e);
                }
                int response = JOptionPane.showConfirmDialog(null, "Do you want to reciept ?", "Conform", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new WithDrawalRecieptPage(password, userId, amount1, res).setVisible(true);
                } else {
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2);
                    new TransictionPage(password).setVisible(true);
                }
            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "You dont have Enough balance:");
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Insufficient Balance ");
        }
    }//GEN-LAST:event_threeThsndButtonActionPerformed

    private void fourThsndButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fourThsndButtonActionPerformed
        // TODO add your handling code here:
        int res = 0;
        int amount1 = 4000;
        int b = Integer.parseInt(amount);
        if (b > 0) {
            if (amount1 < b) {
                res = b - amount1;
                String amount2 = String.valueOf(res);
                String updateQuery = "update accountinfo set amount=" + amount2 + " where password =" + password;
                try {
                    jdbc.stm.executeUpdate(updateQuery);
                   // System.out.print(updateQuery);
                } catch (Exception e) {
                    System.out.print(e);
                }
                int response = JOptionPane.showConfirmDialog(null, "Do you want to reciept ?", "Conform", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new WithDrawalRecieptPage(password, userId, amount1, res).setVisible(true);
                } else {
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2);
                    new TransictionPage(password).setVisible(true);
                }

            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "You dont have Enough balance:");
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Insufficient Balance ");
        }

    }//GEN-LAST:event_fourThsndButtonActionPerformed

    private void fiveThsndButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fiveThsndButtonActionPerformed
        // TODO add your handling code here:
        int res = 0;
        int amount1 = 5000;
        int b = Integer.parseInt(amount);
        if (b > 0) {
            if (amount1 < b) {
                res = b - amount1;
                String amount2 = String.valueOf(res);
                String updateQuery = "update accountinfo set amount=" + amount2 + " where password =" + password;
                try {
                    jdbc.stm.executeUpdate(updateQuery);
                    //System.out.print(updateQuery);
                } catch (Exception e) {
                    System.out.print(e);
                }
                int response = JOptionPane.showConfirmDialog(null, "Do you want to reciept ?", "Conform", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (response == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new WithDrawalRecieptPage(password, userId, amount1, res).setVisible(true);
                } else {
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f, "Your remaining Amount is:" + amount2);
                    new TransictionPage(password).setVisible(true);
                }
            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "You dont have Enough balance:");
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Insufficient Balance ");
        }
    }//GEN-LAST:event_fiveThsndButtonActionPerformed

    private void otherAmountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_otherAmountButtonActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new OtherAmountPage(password).setVisible(true);


    }//GEN-LAST:event_otherAmountButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new TransictionPage(password).setVisible(true);
    }//GEN-LAST:event_BackButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WithDrawPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WithDrawPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WithDrawPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WithDrawPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WithDrawPage(password).setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Amount;
    private javax.swing.JButton BackButton;
    private javax.swing.JButton Thousandbuton;
    private javax.swing.JButton fiveThsndButton;
    private javax.swing.JButton fourThsndButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton otherAmountButton;
    private javax.swing.JButton threeThsndButton;
    private javax.swing.JButton twothosdButton;
    // End of variables declaration//GEN-END:variables
}
